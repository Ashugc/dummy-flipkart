import React, { Component } from 'react'  
import Carousel from 'react-bootstrap/Carousel'  
export class BootstrapCarousel extends Component {  
    render() {  
        return (  
            <div>  
                <Carousel>  
                    <Carousel.Item style={{'height':"300px"}}>  
                    <img style={{'height':"300px"}}  
                    className="d-block w-100"  
                    src="https://rukminim2.flixcart.com/flap/844/140/image/413169a51caa93c9.jpg?q=50" alt=""/>
                        
                    </Carousel.Item>  
                    <Carousel.Item style={{'height':"300px"}}>  
                        <img style={{'height':"300px"}}  
                            className="d-block w-100"  
                            src="https://i.pinimg.com/originals/37/e9/e0/37e9e012b6e0f2a3edf47438f066958d.jpg" alt="" />
                    </Carousel.Item>  
                    <Carousel.Item style={{'height':"300px"}}>  
                        <img style={{'height':"300px"}}  
                        className="d-block w-100"  
                        src="https://m.media-amazon.com/images/I/61-e1sYEjoL._SX3000_.jpg" alt="" />
                    </Carousel.Item>
                    <Carousel.Item style={{'height':"300px"}}>  
                        <img style={{'height':"300px"}}  
                        className="d-block w-100"  
                        src="https://m.media-amazon.com/images/I/61pxhbXv8tL._SX3000_.jpg" alt="" />
                    </Carousel.Item>  
                </Carousel>  
            </div>  
        )  
    }  
}  
export default BootstrapCarousel 